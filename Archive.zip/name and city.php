<html>
<body style="font-family:verdana;">


 Hi, my name is <?php echo $_GET["firstName"]; ?> <?php echo $_GET["lastName"]; ?> and my city is <?php echo $_GET["city"]; ?>

<p><a href="index.html">Return</a></p>
</body>
</html>